//Número conta cetip obrigatório

import org.junit.After;
        import org.junit.Test;
        import org.openqa.selenium.*;
        import org.openqa.selenium.chrome.ChromeDriver;
        import org.junit.Assert;
        import org.openqa.selenium.support.ui.ExpectedConditions;
        import org.openqa.selenium.support.ui.WebDriverWait;


        import java.io.BufferedWriter;
        import java.io.File;
        import java.io.FileWriter;
        import java.io.IOException;
        import java.time.LocalDateTime;
        import java.time.format.DateTimeFormatter;
        import java.util.Date;
        import java.util.concurrent.TimeUnit;

        import static java.lang.Thread.sleep;

public class ValidaNumeroContaCetipObrigatorio {
    //private String FILE_PATH = "C:\\Users\\luplana\\Downloads\\Panilha de Upload\\UPLOAD";
    private String FILE_NAME = null;
    private WebDriver navegador;
    @Test

    public void Uploadm7 () throws InterruptedException {
        GenerateFile();
        try {
            System.setProperty("webdriver.chrome.driver", "C:/Users/Public/WebDriver/chromedriver.exe");
            navegador = new ChromeDriver();
            navegador.manage().window().maximize();
            //navegador.get("https://router-asset-internet.itaud.des.ihf/webasset/webasset/asset/home");
            navegador.get("https://assetfront.dev.cloud.itau.com.br/");
            navegador.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            WebDriverWait wait = new WebDriverWait(navegador, 30);


            TakesScreenshot scrShot = ((TakesScreenshot) navegador);
            File srcFile = scrShot.getScreenshotAs(OutputType.FILE);




            // Digitar o login
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("loginInputEbusiness")));
            wait.until(ExpectedConditions.elementToBeClickable(By.id("loginInputEbusiness")));
            navegador.findElement(By.id("loginInputEbusiness")).click();
            navegador.findElement(By.id("loginInputEbusiness")).sendKeys("abcbrasil.op01");

            //Digitar a senha
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("loginInputSenha")));
            wait.until(ExpectedConditions.elementToBeClickable(By.id("loginInputSenha")));
            navegador.findElement(By.id("loginInputSenha")).click();
            navegador.findElement(By.id("loginInputSenha")).sendKeys("window");
            navegador.findElement(By.id("btnLoginAcessar")).click();

            String teste = navegador.findElement(By.id("tituloHome")).getText();
            Assert.assertEquals("Bem-vindo ao site logado da Asset", teste);

//Clicar no menu Upload
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("operacoes-upload")));
            wait.until(ExpectedConditions.elementToBeClickable(By.id("operacoes-upload")));
            navegador.findElement(By.id("operacoes-upload")).click();

            // wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("fileInputCsv")));
            //wait.until(ExpectedConditions.elementToBeClickable(By.id("fileInputCsv")));
            WebElement uploadElement = navegador.findElement(By.id("fileInputCsv"));

            // enter the file path onto the file-selection input field
            uploadElement.sendKeys(System.getProperty("user.dir") + "\\" + FILE_NAME);

//Enviar planilha
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnEnviar")));
            wait.until(ExpectedConditions.elementToBeClickable(By.id("btnEnviar")));
            navegador.findElement(By.id("btnEnviar")).click();

//Finalizar atividade
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnFinalizar")));
            wait.until(ExpectedConditions.elementToBeClickable(By.id("btnFinalizar")));
            navegador.findElement(By.id("btnFinalizar")).click();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            DeleteFile();
        }
    }

    private void GenerateFile() {
        try {
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMdd");
            DateTimeFormatter dtfSeconds = DateTimeFormatter.ofPattern("HHmmss");
            DateTimeFormatter dtfFile = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDateTime now = LocalDateTime.now();
            FILE_NAME = "GER_" + dtf.format(now) + dtfSeconds.format(now) + ".csv";
            FileWriter writer = new FileWriter(FILE_NAME);
            BufferedWriter bw = new BufferedWriter(writer);

            bw.write("SIGLA_EMPRESA_CONVENIADA;NOME_CLIENTE;CPF_CNPJ_CLIENTE;BANCO_PRINCIPAL_CLIENTE;AGENCIA_PRINCIPAL_CLIENTE;CONTA_PRINCIPAL_CLIENTE;DAC_CONTA_PRINCIPAL_CLIENTE;CO_TIPO_OPERACAO;COD_TIPO_LIQUIDACAO;BANCO_CONTA_ORIGEM;AGENCIA_CONTA_ORIGEM;CONTA_CONTA_ORIGEM;DAC_CONTA_ORIGEM;TIPO_CONTA_ORIGEM;BANCO_CONTA_DESTINO;AGENCIA_CONTA_DESTINO;CONTA_CONTA_DESTINO;DAC_CONTA_DESTINO;TIPO_CONTA_DESTINO;DAT_BASE;COD FUNDO;COD_SUB_CONTA_FUNDO;VL_OPERACAO;IND_RESGATE_TOTAL;COD_FINALIDADE;CETIP_BANCO;CETIP_CONTA");
            bw.newLine();
            bw.write("GER;ULTRAPREV A P COMPLEMENTAR;29981107000140;341;912;4177;9;0;1;;;;;;;;;;;"+ dtfFile.format((now)) +";51214;201;3149;N;1;341;");
            bw.flush();
            bw.close();
            writer.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void DeleteFile() {
        File csv = new File(FILE_NAME);

        csv.delete();
    }

    @After
    public void tearDown() throws Exception {
        //navegador.quit();
    }



}

