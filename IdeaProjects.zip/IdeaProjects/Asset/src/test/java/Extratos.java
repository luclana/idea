import org.junit.After;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.junit.Assert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import java.util.concurrent.TimeUnit;

import static java.lang.Thread.sleep;

public class Extratos {
private WebDriver navegador;
    @Test

    public void testLogin () throws InterruptedException {
        System.setProperty("webdriver.chrome.driver","C:/Users/Public/WebDriver/chromedriver.exe");
        navegador = new ChromeDriver();
        navegador.manage().window().maximize();
        navegador.get("https://router-asset-internet.itaud.des.ihf/webasset/webasset/asset/home");
        //navegador.get("https://assetfront.dev.cloud.itau.com.br/");
        navegador.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        WebDriverWait wait = new WebDriverWait(navegador, 30);

// Digitar o login
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("loginInputEbusiness")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("loginInputEbusiness")));
        navegador.findElement(By.id("loginInputEbusiness")).click();
        navegador.findElement(By.id("loginInputEbusiness")).sendKeys("abcbrasil.op01");

//Digitar a senha
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("loginInputSenha")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("loginInputSenha")));
        navegador.findElement(By.id("loginInputSenha")).click();
        navegador.findElement(By.id("loginInputSenha")).sendKeys("window");
        navegador.findElement(By.id("btnLoginAcessar")).click();

        String teste = navegador.findElement(By.id("tituloHome")).getText();
        Assert.assertEquals("Bem-vindo ao site logado da Asset", teste);

 //Clicar no menu Extratos
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("extratos")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("extratos")));
        navegador.findElement(By.id("extratos")).click();
    }
    @After
    public void tearDown() throws Exception {
        navegador.quit();
    }
}

