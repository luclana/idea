import org.junit.After;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.junit.Assert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import java.util.concurrent.TimeUnit;

import static java.lang.Thread.sleep;

public class CarteiraDiaria {
private WebDriver navegador;
    @Test

    public void testLogin () throws InterruptedException {
        System.setProperty("webdriver.chrome.driver","C:/Users/Public/WebDriver/chromedriver.exe");
        navegador = new ChromeDriver();
        navegador.manage().window().maximize();
        navegador.get("https://router-asset-internet.itaud.des.ihf/webasset/webasset/asset/home");
        //navegador.get("https://assetfront.dev.cloud.itau.com.br/");
        navegador.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        WebDriverWait wait = new WebDriverWait(navegador, 60);

// Digitar o login
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("loginInputEbusiness")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("loginInputEbusiness")));
        navegador.findElement(By.id("loginInputEbusiness")).click();
        navegador.findElement(By.id("loginInputEbusiness")).sendKeys("abcbrasil.op01");

//Digitar a senha
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("loginInputSenha")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("loginInputSenha")));
        navegador.findElement(By.id("loginInputSenha")).click();
        navegador.findElement(By.id("loginInputSenha")).sendKeys("window");
        navegador.findElement(By.id("btnLoginAcessar")).click();

        String teste = navegador.findElement(By.id("tituloHome")).getText();
        Assert.assertEquals("Bem-vindo ao site logado da Asset", teste);

//Clicar no menu Carteira Diaria
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("carteira-diaria")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("carteira-diaria")));
        navegador.findElement(By.id("carteira-diaria")).click();

//Selecionar a caixa PDF
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("labelFormatoPdf")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("labelFormatoPdf")));
        navegador.findElement(By.id("labelFormatoPdf")).click();

//Selecionar a caixa Excel
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("labelFormatoExcel")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("labelFormatoExcel")));
        navegador.findElement(By.id("labelFormatoExcel")).click();

//Selecionar a caixa Todos
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/app-root/app-asset/app-carteira-diaria/div[3]/div[1]/div/app-container-carteiras-fundos/div/div/app-lista-carteiras/div/div[2]/div/div/table/thead/tr/th[1]/label/span")));
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/app-root/app-asset/app-carteira-diaria/div[3]/div[1]/div/app-container-carteiras-fundos/div/div/app-lista-carteiras/div/div[2]/div/div/table/thead/tr/th[1]/label/span")));
        navegador.findElement(By.xpath("/html/body/app-root/app-asset/app-carteira-diaria/div[3]/div[1]/div/app-container-carteiras-fundos/div/div/app-lista-carteiras/div/div[2]/div/div/table/thead/tr/th[1]/label/span")).click();

//Clicar no botao Gerar Relatorios
        //wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("spanTodasCarteiras")));
        //wait.until(ExpectedConditions.elementToBeClickable(By.id("spanTodasCarteiras")));
        sleep(5000);
        navegador.findElement(By.id("spanCarteira_ABSOLUMM50990")).click();
        navegador.findElement(By.id("spanCarteira_CINST53RF51049")).click();
        navegador.findElement(By.id("spanCarteira_EXXONMOBIL")).click();


 // Clicar no botao gerar relatorios

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnDownloadRelatoriosContabeis")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("btnDownloadRelatoriosContabeis")));
        navegador.findElement(By.id("btnDownloadRelatoriosContabeis")).click();

// Clicar no botao download

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnDownload")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("btnDownload")));
        navegador.findElement(By.id("btnDownload")).click();
    }
    @After
    public void tearDown() throws Exception {
        //navegador.quit();
    }
}