import org.junit.After;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.junit.Assert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import java.util.concurrent.TimeUnit;

import static java.lang.Thread.sleep;

public class XMLMensal4 {
private WebDriver navegador;
    @Test

    public void testLogin () throws InterruptedException {
        System.setProperty("webdriver.chrome.driver","C:/Users/Public/WebDriver/chromedriver.exe");
        navegador = new ChromeDriver();
        navegador.manage().window().maximize();
        //navegador.get("https://router-asset-internet.itaud.des.ihf/webasset/webasset/asset/home");
        navegador.get("https://assetfront.dev.cloud.itau.com.br/");
        navegador.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        WebDriverWait wait = new WebDriverWait(navegador, 30);

// Digitar o login
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("loginInputEbusiness")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("loginInputEbusiness")));
        navegador.findElement(By.id("loginInputEbusiness")).click();
        navegador.findElement(By.id("loginInputEbusiness")).sendKeys("abcbrasil.op01");

//Digitar a senha
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("loginInputSenha")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("loginInputSenha")));
        navegador.findElement(By.id("loginInputSenha")).click();
        navegador.findElement(By.id("loginInputSenha")).sendKeys("window");
        navegador.findElement(By.id("btnLoginAcessar")).click();

        String teste = navegador.findElement(By.id("tituloHome")).getText();
        Assert.assertEquals("Bem-vindo ao site logado da Asset", teste);

//Clicar no menu XML
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("xml")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("xml")));
        navegador.findElement(By.id("xml")).click();

//Clicar no botão mensal

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnConsultaMensal")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("btnConsultaMensal")));
        navegador.findElement(By.id("btnConsultaMensal")).click();

//Clicar no botão posição 4.0

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnOpcaoPosicao_4_0")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("btnOpcaoPosicao_4_0")));
        navegador.findElement(By.id("btnOpcaoPosicao_4_0")).click();

//Selecionar um fundo

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("spanCarteira_ABSOLUMM50990")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("spanCarteira_ABSOLUMM50990")));
        navegador.findElement(By.id("spanCarteira_ABSOLUMM50990")).click();


        //Clicar no botão download

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnDownload")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("btnDownload")));
        navegador.findElement(By.id("btnDownload")).click();

    }
    @After
    public void tearDown() throws Exception {
        navegador.quit();
    }
}

