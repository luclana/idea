import org.junit.After;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.junit.Assert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import java.util.concurrent.TimeUnit;

import static java.lang.Thread.sleep;

public class RelatoriosContabeisPeriodoFundoExclusivo {
private WebDriver navegador;
    @Test

    public void testLogin () throws InterruptedException {
        System.setProperty("webdriver.chrome.driver","C:/Users/Public/WebDriver/chromedriver.exe");
        navegador = new ChromeDriver();
        navegador.manage().window().maximize();
        navegador.get("https://router-asset-internet.itaud.des.ihf/webasset/webasset/asset/home");
        //navegador.get("https://assetfront.dev.cloud.itau.com.br/");
        navegador.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        WebDriverWait wait = new WebDriverWait(navegador, 30);

// Digitar o login
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("loginInputEbusiness")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("loginInputEbusiness")));
        navegador.findElement(By.id("loginInputEbusiness")).click();
        navegador.findElement(By.id("loginInputEbusiness")).sendKeys("abcbrasil.op01");

//Digitar a senha
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("loginInputSenha")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("loginInputSenha")));
        navegador.findElement(By.id("loginInputSenha")).click();
        navegador.findElement(By.id("loginInputSenha")).sendKeys("window");
        navegador.findElement(By.id("btnLoginAcessar")).click();

        String teste = navegador.findElement(By.id("tituloHome")).getText();
        Assert.assertEquals("Bem-vindo ao site logado da Asset", teste);

//Clicar no menu Relatorios Contabeis
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("relatorioscontabeis")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("relatorioscontabeis")));
        navegador.findElement(By.id("relatorioscontabeis")).click();

//Clicar no Botao periodo
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnRelatorioPorPeriodo")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("btnRelatorioPorPeriodo")));
        navegador.findElement(By.id("btnRelatorioPorPeriodo")).click();

//Selecionar os checkbox PDF
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("labelFormatoPdf")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("labelFormatoPdf")));
        navegador.findElement(By.id("labelFormatoPdf")).click();

//Selecionar os checkbox Excel
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("labelFormatoExcel")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("labelFormatoExcel")));
        navegador.findElement(By.id("labelFormatoExcel")).click();

//Selecionar extrair por fundo exclusivo
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnFundoExclusivo")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("btnFundoExclusivo")));
        navegador.findElement(By.id("btnFundoExclusivo")).click();

//Clicar no botao adicionar todas as carteiras
        //wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnAdicionarTodos_carteirasEFundos")));
        //wait.until(ExpectedConditions.elementToBeClickable(By.id("btnAdicionarTodos_carteirasEFundos")));
        sleep(1000);
        navegador.findElement(By.id("btnAdicionarTodos_carteirasEFundos")).click();

//Clicar no botao adicionar todos os relatorios
        //wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnAdicionarTodos_relatorios")));
        //wait.until(ExpectedConditions.elementToBeClickable(By.id("btnAdicionarTodos_relatorios")));
        sleep(1000);
        navegador.findElement(By.id("btnAdicionarTodos_relatorios")).click();

//Clicar no botao Gerar Relatorios
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnDownloadRelatoriosContabeis")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("btnDownloadRelatoriosContabeis")));
        navegador.findElement(By.id("btnDownloadRelatoriosContabeis")).click();

//Clicar no checkbox do relatorio gerado
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("labelTodosRelatorios")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("labelTodosRelatorios")));
        navegador.findElement(By.id("labelTodosRelatorios")).click();

//Clicar no botao download
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnDownload")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("btnDownload")));
        navegador.findElement(By.id("btnDownload")).click();
    }
    @After
    public void tearDown() throws Exception {
        navegador.quit();
    }
}