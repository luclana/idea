import org.junit.After;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.junit.Assert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import java.util.concurrent.TimeUnit;

import static java.lang.Thread.sleep;

public class ExtratoMensal {
private WebDriver navegador;
    @Test

    public void testLogin () throws InterruptedException {
        System.setProperty("webdriver.chrome.driver","C:/Users/Public/WebDriver/chromedriver.exe");
        navegador = new ChromeDriver();
        navegador.manage().window().maximize();
        navegador.get("https://router-asset-internet.itaud.des.ihf/webasset/webasset/asset/home");
        //navegador.get("https://assetfront.dev.cloud.itau.com.br/");
        navegador.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        WebDriverWait wait = new WebDriverWait(navegador, 30);

// Digitar o login
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("loginInputEbusiness")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("loginInputEbusiness")));
        navegador.findElement(By.id("loginInputEbusiness")).click();
        navegador.findElement(By.id("loginInputEbusiness")).sendKeys("abcbrasil.op01");

//Digitar a senha
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("loginInputSenha")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("loginInputSenha")));
        navegador.findElement(By.id("loginInputSenha")).click();
        navegador.findElement(By.id("loginInputSenha")).sendKeys("window");
        navegador.findElement(By.id("btnLoginAcessar")).click();

        String teste = navegador.findElement(By.id("tituloHome")).getText();
        Assert.assertEquals("Bem-vindo ao site logado da Asset", teste);

//Clicar no menu Extratos
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("extratos")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("extratos")));
        navegador.findElement(By.id("extratos")).click();

//Clicar no botão mensal
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnExtratosMensal")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("btnExtratosMensal")));
        navegador.findElement(By.id("btnExtratosMensal")).click();

//Clicar no botão extrato diário
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnExtratoDiario")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("btnExtratoDiario")));
        navegador.findElement(By.id("btnExtratoDiario")).click();

//Clicar no CHECK BOX todos
        //wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("colunaSelecionarTodasContasExtrato")));
        //wait.until(ExpectedConditions.elementToBeClickable(By.id("colunaSelecionarTodasContasExtrato")));
        sleep(2000);
        navegador.findElement(By.id("colunaSelecionarTodasContasExtrato")).click();

//Clicar no botão EXPORTAR
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("exportarExtrato")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("exportarExtrato")));
        navegador.findElement(By.id("exportarExtrato")).click();
    }
    @After
    public void tearDown() throws Exception {
        navegador.quit();
    }
}



